package com.panagisj1.whowantstobemillionairejp;

import static android.os.Build.VERSION_CODES.R;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;



public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        getSupportActionBar().hide();
    }

    public void Play(View view){
        Intent i =  new Intent(this, MainActivity.class);
        startActivity(i);
    }

    public void Rules(View view){
        Intent i =  new Intent(this, HelpActivity.class);
        startActivity(i);
    }
}