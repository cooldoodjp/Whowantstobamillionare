package com.panagisj1.whowantstobemillionairejp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class SplashActivity extends AppCompatActivity {

    ImageView splash_image;
    Animation topAnimation, downAnimation;
    Handler handler;
    TextView tvWelcome;
    final int TIME_LIMIT = 8000;     // The time delay after splash screen in milliseconds.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        getSupportActionBar().hide();

        splash_image = findViewById(R.id.logo_id);
        topAnimation = AnimationUtils.loadAnimation(this, R.anim.rotate);
        topAnimation.setFillAfter(true);
        splash_image.startAnimation(topAnimation);

        // postDelayed(Runnable, time) method is used to start the second activity with a delay
        handler=new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent=new Intent(SplashActivity.this, HomeActivity.class);
                startActivity(intent);
                finish();
            }
        },TIME_LIMIT);
    }
}